﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num1, num2;
            num1 = Convert.ToInt32(textBox1.Text);
            num2 = Convert.ToInt32(textBox1.Text);
            ServiceReference1.CalcServiceSoapClient proxy = new ServiceReference1.CalcServiceSoapClient();//Creating proxy object of Web Service

            if (comboBox1.Text == "Add")
            {
                MessageBox.Show(proxy.Add(num1, num2).ToString());//Calling Add method of CalcWeb Service
            }
            else if (comboBox1.Text == "Sub")
            {
                MessageBox.Show(proxy.Sub(num1, num2).ToString());
            }
            else if (comboBox1.Text == "Mul")
            {
                MessageBox.Show(proxy.Mult(num1, num2).ToString());
            }
            else if (comboBox1.Text == "Div")
            {
                MessageBox.Show(proxy.Div(num1, num2).ToString());
            }

        }
    }
}
